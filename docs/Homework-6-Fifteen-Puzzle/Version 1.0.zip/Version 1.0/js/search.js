/* search.js, created by Yongye Fan, 12/11/2018 */
// initialize global variables
var searchOpenList = [];     // the list of nodes which have been found but have not been searched
var searchCloseList = [];    // the list of nodes' states which have been searched

// JigsawNode
function JigsawNode(state, parent, dimension) {
  this.state = state;
  this.parent = parent;
  this.dimension = dimension;

  this.nodeDepth = (function() {
    if (parent == null) return 0;

    return parent.nodeDepth + 1;
  })();

  this.estimatedValue = 0;

  this.setEstimatedValue = function(estimatedValue) {
    this.estimatedValue = estimatedValue;
  };

  this.equals = function(anotherNode) {
    var anotherState = anotherNode.state;

    for (var i = anotherState.length - 1; i >= 0; i--) {
      if (anotherState[i] != state[i]) return false;
    }

    return true;
  };
}

// change index into coordinate according to the jigsaw dimension
function findCoordinate(index, dimension) {
  var coordinate = [];

  coordinate.push(parseInt(index / dimension));
  coordinate.push(index % dimension);
  return coordinate;
}

// estimate the jigsaw node's estimatedValue
function estimateValue(AJigsawNode) {
  // Manhattan distance
  // add all Manhattan distances between jigsaws and their correctly positioned div parts
  var hValue = (function() {
    var h = 0;
    var xDiffer = 0;
    var yDiffer = 0;
    var state = AJigsawNode.state;
    var dimension = AJigsawNode.dimension;

    for (var i = 0; i < state.length; i++) {
      if (state[i] == Math.pow(dimension, 2) - 1) continue;

      xDiffer = Math.abs((findCoordinate(state[i], dimension))[0] - (findCoordinate(i, dimension))[0]);
      yDiffer = Math.abs((findCoordinate(state[i], dimension))[1] - (findCoordinate(i, dimension))[1]);
      h = h + xDiffer + yDiffer;
    }

    return h;
  })();

  // the number of wrong positioned jigsaws
  var pValue = (function() {
    var p = 0;
    var state = AJigsawNode.state;

    for (var i = state.length - 1; i >= 0; i--) {
      if (state[i] != i) p++;
    }

    return p;
  })();

  // the search node depth of this jigsaw node
  var gValue = AJigsawNode.nodeDepth;

  // Evaluation function
  var fn = parseInt(10 * hValue + 2 * pValue + 5 * gValue);

  AJigsawNode.setEstimatedValue(fn);
}

function adjacentToBlank(jigsawIndex, blankIndex, dimension) {
  var jigsawCoor = findCoordinate(jigsawIndex, dimension);
  var blankCoor = findCoordinate(blankIndex, dimension);

  var xDiffer = jigsawCoor[0] - blankCoor[0];
  var yDiffer = jigsawCoor[1] - blankCoor[1];

  return (xDiffer == 0 && yDiffer == 1) ||
         (xDiffer == 0 && yDiffer == -1) ||
         (xDiffer == 1 && yDiffer == 0) ||
         (xDiffer == -1 && yDiffer == 0);
}

function exchange(array, index1, index2) {
  var newArray = Array.apply(this, array);
  var temp = newArray[index1];
  newArray[index1] = newArray[index2];
  newArray[index2] = temp;

  return newArray;
}

function findChildNodes(AJigsawNode) {
  var jigsawState = AJigsawNode.state;
  var dimension = AJigsawNode.dimension;
  var blankIndex;

  for (var i = jigsawState.length - 1; i >= 0; i--) {
    if (jigsawState[i] == Math.pow(dimension, 2) - 1) {
      blankIndex = i;
      break;
    }
  }

  var adjacentIndex = [];

  for (var j = jigsawState.length - 1; j >= 0; j--) {
    if (adjacentToBlank(j, blankIndex, dimension)) adjacentIndex.push(j);
  }

  // create child nodes
  var childNodes = [];
  for (var k = 0; k < adjacentIndex.length; k++) {
    var newArr = exchange(jigsawState, adjacentIndex[k], blankIndex);
    var hasBeenSearched = false;

    // this node can not be in searchCloseList as well
    // for (var p = 0; p < searchCloseList.length; p++) {
    //   if (searchCloseList[p].state.toString() == newArr.toString()) {
    //     hasBeenSearched = true;
    //     break;
    //   }
    // }

    if ($.inArray(newArr, searchCloseList) != -1) {
      hasBeenSearched = true;
      break;
    }

    if (!hasBeenSearched) childNodes.push(new JigsawNode(newArr, AJigsawNode, dimension));
  }

  return childNodes;
}

// insert the jigsaw node into searchOpenList according to its estimatedValue
function insertOpenList(AJigsawNode) {
  // var estimatedValue = AJigsawNode.estimatedValue;

  // for (var i = 0; i < searchOpenList.length; i++) {
  //   if (estimatedValue < searchOpenList[i].estimatedValue) {
  //     var tempList = searchOpenList.slice(0, i);
  //     tempList.push(AJigsawNode);
  //     tempList.concat(searchOpenList.slice(i));

  //     searchOpenList = tempList;
  //     return;
  //   }
  // }

  searchOpenList.push(AJigsawNode);

  // sort according to estimatedValue
  function compare(property) {
    return function(jigsawNode1, jigsawNode2) {
      var value1 = jigsawNode1[property];
      var value2 = jigsawNode2[property];
      return value1 - value2;
    };
  }
  searchOpenList.sort(compare("estimatedValue"));
}

function findPath(pathList, destNode) {
  var currentNode = destNode;

  while (currentNode.parent != null) {
    pathList.unshift(currentNode.state);
    currentNode = currentNode.parent;
  }

  pathList.unshift(currentNode.state);
}

// search the jigsaw state (array) path
function ASearch(startNode, destNode) {
  // max search number
  var maxSearchNum = 20000;
  var findDest = false;

  insertOpenList(startNode);

  var currentNode;
  var childNodes;
  var searchPath = [];

  while (searchOpenList.length != 0 && searchCloseList.length < maxSearchNum) {
    currentNode = searchOpenList.shift();

    if (currentNode.equals(destNode)) {
      findDest = true;
      break;
    }

    // push into close list first, then find child nodes
    searchCloseList.push(currentNode.state);
    childNodes = findChildNodes(currentNode);
    // add child nodes into open list according to their estimatedValue
    for (var i = 0; i < childNodes.length; i++) {
      insertOpenList(childNodes[i]);
    }
  }

  if (findDest) {
    // find search path
    findPath(searchPath, currentNode);
    console.log("Search successfully!\nTotal search states: ", searchCloseList.length);
  } else {
    console.log("Can not find dest!\nTotal search states: ", searchCloseList.length);
  }

  // Clear search lists
  searchOpenList = [];
  searchCloseList = [];

  return searchPath;
}
